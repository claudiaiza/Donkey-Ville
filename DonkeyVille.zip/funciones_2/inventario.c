#include <stdio.h>

int tieneFlorRoja;
int tieneFlorAmarilla;
int tieneHerradura;
int encontradaHerradura;
int encontradaNota;
int entregadaFlorRoja;
int entregadaFlorAmarilla;
int encendidoFaro;
int puestaHerradura;
int flores;


void IniciarInventario()
{
    tieneFlorRoja =0;
    tieneFlorAmarilla =0;
    tieneHerradura=0;
    encontradaHerradura=0;
    encontradaNota=0;
    entregadaFlorRoja;
    entregadaFlorAmarilla=0;
    encendidoFaro=0;
    puestaHerradura=0;
    flores = 0;
}

int ObtenerTieneFlorRoja()
{
    return tieneFlorRoja;
}

void Recoger ()
{
    int e;

    e = ObtenerEscena();

    printf("Cogiendo objeto\n");
    if (e==1)
    {
        printf("No hay nada que recoger aqui\n");

    }
    else if (e==2)
    {
        printf("Has cogido la nota\n");

        encontradaNota =1;
    }
    else if (e==2 && encontradaNota == 1)
    {
        printf("Ya tienes la nota\n");
    }
    else if(e==3)
    {
        printf("No hay nada que recoger aqui\n");
    }
    else if(e==4)
    {
        printf("No hay nada que recoger aqui\n");
    }
    else if(e==5)
    {
        printf("Has cogido la flor amarilla\n");
        tieneFlorAmarilla = 1;
        entregadaFlorAmarilla = 0;
    }
    else if(e==5 && tieneFlorAmarilla==1)
    {
        printf("Ya tienes la flor amarilla\n");
    }
    else if(e==6 && !ConversaMadeline())
    {
        printf("Has cogido la flor roja\n");
        tieneFlorRoja = 1;
        entregadaFlorRoja =0;
    }
    else if(e==6 && !ConversaMadeline() && tieneFlorRoja ==1)
    {
        printf("Ya has cogido la flor roja\n");
    }
    else if(e==6 && ConversaMadeline()==1)
    {
         printf("Has cogido la herradura azul\n");
         tieneHerradura = 1;
    }
    else if(e==6 && ConversaMadeline()==1 && tieneFlorRoja==1)
    {
         printf("Ya has cogido la flor roja\n");
    }
    else if(e==6 && ConversaMadeline()==1 && tieneHerradura==1)
    {
         printf("Ya has cogido la herradura\n");
    }   
}

void Usar ()

{
    int e;
    int opcion;
    opcion=0;

    e = ObtenerEscena();
    
    printf("que objeto quieres usar?\n");
    printf("1- Nota\n");
    printf("2- Flor roja\n");
    printf("3- Flor Amarilla\n");
    printf("4- Herradura\n");
    printf("5- Flores\n");

    scanf("%d", &opcion);

    if (e==1)
    {
        printf("No hay nada que usar aqui\n");
    }
    else if(e==2 && tieneFlorAmarilla ==0 && opcion ==3)
    {
        printf("No tienes la flor amarilla, ve a buscarla al bosque sur\n");
    }
    else if(e==2 && tieneFlorRoja ==0 && opcion ==2)
    {
        printf("No tienes la flor roja, ve a buscarla al bosque norte\n");
    }
    else if(e==2 && opcion==4)
    {
         printf("No puedes usar la herradura aqui\n");
    }
    else if (e==2 && opcion ==1)
    {
        printf("Has usado la nota\n");
        printf("El farero esta enfermo, debes dejarle estos objetos en el buzon:\n");
        printf("Flor roja, se encuentra en el bosque norte\n");
        printf("Flor amarilla, se encuentra en el bosque sud\n");
    }
   else if(e==2 && opcion ==3 && tieneFlorAmarilla == 1)
    {
        printf("Has usado la flor amarilla\n");
        tieneFlorAmarilla = 0;
        entregadaFlorAmarilla = 1;
    }
    else if (e==2 && tieneFlorRoja == 1 && opcion==2)
    {
        printf("Has usado la flor roja\n");
        tieneFlorRoja = 0;
        entregadaFlorRoja = 1;
    }
    else if(e==2 && opcion ==5)
    {
        printf("Debes entregar las flores por separado. Una vez entregadas, ve al faro y usa las flores\n");
    }  
    else if(e==3 && opcion==4 && tieneHerradura==0 && encendidoFaro==1 || e==3 && opcion==4 && tieneHerradura ==1 && encendidoFaro==0)
    {
        printf("Todavia te faltan objetos, comprueba si tienes la herradura o si el faro esta encendido\n");
    }
    else if(e== 3 && opcion==4 && tieneHerradura == 1 && encendidoFaro == 1 && entregadaFlorAmarilla == 1 && entregadaFlorRoja ==1 && encontradaNota ==1)
    {
        printf("Poniendo herradura...\n");
        printf("Felicidades has encontrado el tesoro, has finalizado el juego\n");
        puestaHerradura = 1;
        encendidoFaro = 0;
        JuegoFinalizado(1);
    }
    else if(e==3 && opcion==4 && tieneHerradura=0)
    {
        printf("Todavia no tienes la herradura, ve al bosque norte y habla con Madeleine\n");
    }
    else if(e==3 && opcion==1 || e==3 && opcion==3 ||  e==3 && opcion==2 ||  e==3 && opcion==5)
    {
        printf("No puedes usar este objeto aqui\n");
    }
    else if(e==3 && opcion==1 || e==3 && opcion==3 ||  e==3 && opcion==2 ||  e==3 && opcion==5)
    {
        printf("No puedes usar este objeto aqui\n");
    }
    else if(e==4 && opcion==1 || e==4 && opcion==3 ||  e==4 && opcion==2 ||  e==4 && opcion==4)
    {
        printf("No puedes usar este objeto aqui\n");
    }
    else if (e==4 && opcion==5)
    {
        printf("El farero ha encendido el faro, puedes dirigirte hacia el lago toga para encontrarte a Blue Donkey y poner la herradura\n");
        encendidoFaro = 1;
        flores =1
    }
    else if(e==4 && flores==0)
    {
        printf("Todavia no puedes encender el faro, entrega la flor roja y amarilla en la casa del farero\n");
    }
    if (e==5)
    {
        printf("No hay nada que usar aqui\n");
    }
    if (e==6)
    {
        printf("No hay nada que usar aqui\n");
    }
}