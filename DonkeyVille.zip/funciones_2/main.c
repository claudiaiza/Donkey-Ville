#include <stdio.h>	

int tieneFlorRoja;
int finish;

int JuegoFinalizado = 0;

void main ()
{
    int opcion;

    IniciarEscenas ();
    IniciarInventario ();

    while(JuegoFinalizado !=1)
    {

        DescribeEscena ();

        printf("eligue la opcion que quieras realizar\n");

        printf("1- Hablar Esparrou\n");
        printf("2- Hablar madeleine\n");
        printf("3- Hablar Kaneda\n");
        printf("4- Ir a\n");
        printf("5- Recoger objeto\n");
        printf("6- Usar objeto\n");
    

        scanf("%d", &opcion);

        if (opcion == 1)
        {
            HablarEsparrou ();
        }
        else if (opcion == 2)
        {
            HablarMadeleine ();
        }
        else if (opcion == 3)
        {
            HablarKaneda ();
        }
        else if (opcion == 4)
        {
            IrA ();
        }
        else if (opcion == 5)
        {
            Recoger ();
        }
        else if (opcion == 6)
        {
            Usar ();
        }
    }    
}