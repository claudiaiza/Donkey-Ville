#include <stdio.h>


int escena;
int opcion;

void IniciarEscenas ()
{
    escena = 1;
}
int ObtenerEscena ()
{
    return escena;
}
void DescribeEscena ()
{
    if (escena ==1)
    {
        printf("Te encuentras en DonkeyVille\n");
    }
    else if (escena ==2)
    {
        printf("Estas en la casa del farero\n");
    }
    else if (escena ==3)
    {
        printf("Bienvenido al lago Toga\n");
    }
    else if (escena ==4)
    {
        printf("Hay una faro\n");
    }
    else if (escena ==5)
    {
        printf("Bienvenido al Bosque Sur\n");
    }
    else if (escena ==6)
    {
        printf("Estas en el Bosque Norte\n");
    }
}

int PuedeIr(int escena1, int escena2)
{

    if (escena1 == 1 && escena2 == 2)
    {
        return 1;
    }
    else  if (escena1 == 2 && escena2 == 1)
    {
        return 1;
    }
    else if (escena1 == 1 && escena2 == 3)
    {
        return 1;
    }
    else if (escena1 == 3 && escena2 == 1)
    {
        return 1;
    }
    else if (escena1 == 1 && escena2 == 6)
    {
        return 1;
    }
    else if (escena1 == 6 && escena2 == 1)
    {
        return 1;
    }
    else if (escena1 == 3 && escena2 == 5)
    {
        return 1;
    }
    else if (escena1 == 5 && escena2 == 3)
    {
        return 1;
    }
    else if (escena1 == 3 && escena2 == 4)
    {
        return 1;
    }
    else if (escena1 == 4 && escena2 == 3)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}
void IrA ()
{

    printf("Cambiando escena\n");

    printf("1- DonkyeVille\n");
    printf("2- Casa farero\n");
    printf("3- Lago Toga\n");
    printf("4- Faro\n");
    printf("5- Bosque sur\n");
    printf("6- Bosque norte\n");
    
    scanf("%d", &opcion);

    if(PuedeIr(escena, opcion))
    {
        escena = opcion;
    }
    else
    {
        printf("No puedes ir a este lugar porque todavia estas demasiado lejos, visita otras localidades para llegar a tu destino\n");
    }  
}