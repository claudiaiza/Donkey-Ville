#include <stdio.h>

int conversaMadeline;

void HablarKaneda ()
{
    int e;

    e = ObtenerEscena();

    printf("Hola soy Kaneda\n");

    if(e ==1)
    {
        printf("El farero del pueblo esta enfermo, puedes ir a visitarlo\n");
    }
    else if(e==2)
    {
        printf("Habla con Madeleine\n");
    }
    else if(e==3)
    {
        printf("Blue Donkey suele frecuentar el lago para beber de el, pero solo viene si el faro esta encendido\n");
        printf("Para encenderlo, deberas entregar la flor roja y la flor amarilla en la casa del farero para que este venga y lo encienda\n");
    }
    else if(e==4)
    {
        printf("Blue Donkey suele frecuentar el lago para beber de el, pero solo viene si el faro esta encendido\n");
        printf("Para encenderlo, deberas entregar la flor roja y la flor amarilla en la casa del farero para que este venga y lo encienda\n");
    }
    else if(e==5)
    {
        printf("Creo que Esparrou puede ayudarte\n");
    }
    else if(e==6)
    {
        printf("Creo que Esparrou puede ayudarte\n");
    }
}

int ConversaMadeline()
{
    return conversaMadeline;
}

void HablarMadeleine ()
{
    int e;

    e = ObtenerEscena();

    printf("Hola soy Madeleine\n");

    if(e ==1)
    {
        printf("Creo que Kaneda puede ayudarte\n");
    }
    else if(e ==2)
    {
        printf("Hay una nota en la puerta, recogela y usala\n");
    }
    else if(e==3)
    {
        printf("Creo que Kaneda puede ayudarte\n");
    }
    else if(e==4)
    {
        printf("Creo que Kaneda puede ayudarte\n");
    }
    else if(e==5)
    {
        printf("Creo que Esparrou puede ayudarte\n");
    }
    else if(e==6)
    {
        printf("Parece que hay una herradura azul, prueba de recogerla\n");
        conversaMadeline = 1;
    }
}

void HablarEsparrou ()
{
    int e;

    e=ObtenerEscena();

    printf("Hola soy Esparrou\n");

    if(e==1)
    {
        printf("Debes ir a la casa del farero\n");
    }
    else if(e==2)
    {
        printf("Me parece que hay que buscar los objetos en los bosques\n");
    }
    else if(e==3)
    {
        printf("Kaneda puede ayudarte\n");
    }
    else if(e==4)
    {
        printf("Kaneda puede ayudarte\n");
    }
    else if(e==5)
    {
        printf("Debes encontrar una flor amarilla\n");
    }
    else if(e==6)
    {
        printf("Debes encontrar una flor roja y hablar con Madeleine\n");
    }  
}
